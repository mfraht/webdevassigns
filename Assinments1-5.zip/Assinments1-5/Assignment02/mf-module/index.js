var rg = require( './sendgreeting' );

// console.log( greeting.greeting() );